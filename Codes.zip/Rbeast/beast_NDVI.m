

clc;clear;

%% 功能：实现D:\juLUCC\cropdata\ave_evi 文件夹下2000-2022年tif数据的批量读取，
%  并形成年平均产品

% 设置数据文件夹路径
baseFolder = 'D:\LYGNDVI\NDVI Clip';

% 初始化年份
years = 2000:2023; % 年份范围
numYears = length(years);
numFiles = 0; % 每年文件数量
tifFiles = []; % 存储所有 tif 文件信息

% 收集所有年份的 tif 文件
for year = years
    folderName = fullfile(baseFolder, num2str(year));
    filePattern = fullfile(folderName, '*.tif');
    tifFilesYear = dir(filePattern);
    
    % 更新每年的 tif 文件数量
    numFiles = numFiles + length(tifFilesYear);
    
    % 整合所有文件信息
    tifFiles = [tifFiles; tifFilesYear]; % 连接结构数组
end

% 处理图像的大小和初始化矩阵
if numFiles > 0
    firstFile = fullfile(baseFolder, num2str(years(1)), tifFiles(1).name);
    [firstImage, R] = readgeoraster(firstFile); % 使用 readgeoraster 函数读取图像
    [rows, cols] = size(firstImage);
else
    error('没有找到任何 tif 文件。');
end

% 初始化三维矩阵和日期矩阵
ndviMatrix = zeros(rows, cols, numFiles);
timeMatrix = strings(numFiles, 1);

% 文件索引
fileIndex = 1;

% 逐个读取 tif 文件
for year = years
    folderName = fullfile(baseFolder, num2str(year));
    filePattern = fullfile(folderName, '*.tif');
    tifFilesYear = dir(filePattern);
    
    for k = 1:length(tifFilesYear)
        % 生成文件名，并读取图像
        fileName = tifFilesYear(k).name;
        fullFileName = fullfile(folderName, fileName);
        
        % 使用 readgeoraster 读取图像
        ndviImage = readgeoraster(fullFileName); 
        
        % 存储数据到三维矩阵
        ndviMatrix(:, :, fileIndex) = ndviImage;
             
        % 提取年份和月份
        yearStr = fileName(26:29); % 从文件名中提取年份（前4个字符）
        monthStr = fileName(30:31); % 从文件名中提取月份（第5到第6个字符）

        % 转换字符串为数字
        year = str2double(yearStr);
        month = str2double(monthStr);

        % 构建日期（只保留年份和月份）
        dateValue = datetime(year, month, 1); % 使用年月生成日期，默认日为1号
        timeMatrix(fileIndex) = datestr(dateValue, 'yyyy-mm'); % 保存日期为'yyyy-mm'格式

        % 更新文件索引
        fileIndex = fileIndex + 1;
    end
end

% 打印时间矩阵以确认
disp(timeMatrix);


ndviMatrix(ndviMatrix < 0) = NaN; 
ndviMatrix(ndviMatrix == -9999) = NaN; 
ndviMatrix(ndviMatrix == 670) = NaN; 
ndviMatrix=ndviMatrix*0.0001;


% imagesc(ndviMatrix(:,:,1));colormap(jet);


bsss=(reshape(nanmean(nanmean(ndviMatrix)),1,287))';
result = beast(bsss, 'start', [2000, 2], 'deltat', 1/12, ...
               'period', 1, 'season', 'harmonic', ...
               'scp.minmax', [0, 2], 'tcp.minmax', [0,2], ...
               'mcmc.samples', 10000, 'mcmc.burnin', 1000, ...
               'mcmc.thin', 10, 'mcmc.chains', 3, ...
               'print.progress', true, 'print.options', true);

% 打印结果
printbeast(result);

% 绘制结果
figure;plotbeast(result);