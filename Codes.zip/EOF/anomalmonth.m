function [X]=anomalmonth(data_region,timedata,start_year,start_month,end_year,end_month)
% start_year = 1997;
% start_month = 9;
% end_year = 2023;
% end_month = 6;
num_months = (end_year - start_year) * 12 + end_month - start_month + 1; % 计算非完整年月的月份数量

if start_month==1 && end_month==12
    X=zeros(size(data_region));
    for i=1:12
        X(i:12:timedata-12+i,:)=data_region(i:12:end,:) - repmat( mean(data_region(i:12:end,:),1) , size(data_region(i:12:end,:),1), 1);
    end
elseif start_month~=1 || end_month~=12 || (start_month~=1 && end_month~=12)
    X = zeros(size(data_region));
    for i = 1:num_months
        month_index = mod(start_month + i - 2, 12) + 1; % 计算当前月份在一个循环年内的索引（1-12）
        avg_data = mean(data_region(month_index:12:end, :), 1); % 计算当前月份的平均值
        X(month_index:12:end, :) = data_region(month_index:12:end, :) - repmat(avg_data, size(data_region(month_index:12:end, :), 1), 1);
    end
end
end