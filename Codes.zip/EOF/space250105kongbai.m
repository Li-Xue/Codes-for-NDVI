% 调整大小和位置
figure('Units', 'normalized', 'Position', [0.1, 0.1, 0.4, 0.6]); 

subplot(2,1,1)
load('colormap_sio.mat');

[X, Y] = meshgrid(Lon, Lat); % 构建二维经纬度数据

% 自定义经度和纬度范围
loe = 118.3; low = 119.9;  % 自定义经度范围
las = 33.85; lan = 35.2;   % 自定义纬度范围

data4 = data_area3(:,1); 
data5 = reshape(data4, sizedata(1), sizedata(2))';  % 数据重构

m_proj('mercator', 'long', [loe low], 'lat', [las lan]);  % 矩形投影
m_grid('box', 'on', 'tickdir', 'off', 'fontsize', 16, 'Fontname', 'Times New Roman', ...
       'fontweight', 'bold', 'ytick', 4, 'xtick', 4); 
hold on;

% 绘制 pcolor 图
m_pcolor(X, Y, data5');
shading interp; 
colormap(turbo);  % 设置颜色图
hold on;

% 绘制城市边界
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市';
S = m_shaperead(shapefile);
for i = 1:length(S.ncst)
    coords = S.ncst{i}; 
    m_plot(coords(:,1), coords(:,2), 'k', 'LineWidth', 1); % 黑色边界
    hold on;
end

% 设置 colorbar
hBar = colorbar;
 clim([-0.008 0.008]);  % 设置数据范围
set(hBar, 'FontSize', 12, 'Fontname', 'Times New Roman');
set(get(hBar, 'Title'), 'string', '', 'FontSize', 16, 'Fontname', 'Times New Roman');
title('EOF1 37.7%', 'FontSize', 16, 'FontName', 'Times New Roman');

% 调整colorbar颜色范围，0为白色，负值为冷色，正值为暖色
%clim([-0.01 0.02]);  % 设置colorbar的范围

% 设置colorbar的背景和颜色
colormap(brewermap(256, 'RdBu'));  % 使用正负颜色渐变的色图，0为白色

%% 第二个子图
subplot(2,1,2)
load('colormap_sio.mat');

[X, Y] = meshgrid(Lon, Lat); % 构建二维经纬度数据

% 自定义经度和纬度范围
loe = 118.3; low = 119.9;  % 自定义经度范围
las = 33.85; lan = 35.2;   % 自定义纬度范围

data4 = data_area3(:,2);
data5 = reshape(data4, sizedata(1), sizedata(2))';  % 数据重构

m_proj('mercator', 'long', [loe low], 'lat', [las lan]);  % 矩形投影
m_grid('box', 'on', 'tickdir', 'off', 'fontsize', 16, 'Fontname', 'Times New Roman', ...
       'fontweight', 'bold', 'ytick', 4, 'xtick', 4); 
hold on;

% 绘制 pcolor 图
m_pcolor(X, Y, data5');
shading interp; 
colormap(turbo);  % 设置颜色图
hold on;

% 绘制城市边界
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市';
S = m_shaperead(shapefile);
for i = 1:length(S.ncst)
    coords = S.ncst{i}; 
    m_plot(coords(:,1), coords(:,2), 'k', 'LineWidth', 1); % 黑色边界
    hold on;
end

% 设置 colorbar
hBar = colorbar;
clim([-0.02 0.02]);  % 设置数据范围
set(hBar, 'FontSize', 12, 'Fontname', 'Times New Roman');
set(get(hBar, 'Title'), 'string', '', 'FontSize', 16, 'Fontname', 'Times New Roman');
title('EOF2 9.8%', 'FontSize', 16, 'FontName', 'Times New Roman');

% 调整colorbar颜色范围，0为白色，负值为冷色，正值为暖色
%clim([-0.01 0.02]);  % 设置colorbar的范围
colormap(brewermap(256, 'RdBu'));  % 使用正负颜色渐变的色图，0为白色

% 统一字体设置，确保经纬度标注样式一致
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);
