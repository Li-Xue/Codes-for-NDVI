

 figure('Units', 'normalized', 'Position', [0.1, 0.1, 0.4, 0.6]); % 调整大小和位置

 subplot(2,1,1)
load('colormap_sio.mat');
% 
% lonlim = [118.3 119.9];
% latlim = [33.85 35.2];

[X, Y] = meshgrid(Lon,Lat);            %构建二维经纬度数据
%    loe=119;low=123;                     %自定义经度范围
%     las=32;lan=37;                      %自定义纬度范围
     loe=118.3;low=119.9;                     %自定义经度范围
    las=33.85;lan=35.2;                      %自定义纬度范围

data4=data_area3(:,1);data5=reshape(data4,sizedata(1),sizedata(2))';%sst6=rot90(sst5,2);
m_proj('mercator','long',[loe low],'lat',[las lan]);      %矩形投影；
m_grid('box','on','tickdir','off','fontsize',16,'Fontname','Time New Roman',...
      'fontweight','bold','ytick',4,'xtick',4);hold on;

m_pcolor(X, Y,data5');  %Makes a pcolor image on a map.
shading interp; 
hold on;
 colormap(turbo);
%m_gshhs_f('patch',[0.5 0.5 0.5],'EdgeColor','k','LineWidth',1.2);
% colormap(colormap_sio);
% cLim = [min(yTick(:)) max(yTick(:))];

shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市';
S = m_shaperead(shapefile);

% 遍历每个多边形（城市边界）
for i = 1:length(S.ncst)
    coords = S.ncst{i}; % 获取第 i 个城市的坐标
    % 绘制边界
    m_plot(coords(:,1), coords(:,2), 'k', 'LineWidth', 1); % 黑色边界，线宽 1.5
    hold on; % 确保不会覆盖之前的绘制
end

% 结束绘图
hold off;

hBar = colorbar;
  clim([-0.004 0.008]);
set(hBar,'Fontsize',12,'Fontname','Time New Roman');
set(get(hBar, 'Title'), 'string', '', 'Fontsize', 16, 'Fontname', 'Times New Roman');
% title(hBar, '(μg/m³)', 'FontSize', 16, 'FontName', 'Times New Roman');
title('EOF1 37.7%', 'FontSize', 16, 'FontName', 'Times New Roman');

%%
 subplot(2,1,2)
load('colormap_sio.mat');
% 
% lonlim = [118.3 119.9];
% latlim = [33.85 35.2];

[X, Y] = meshgrid(Lon,Lat);            %构建二维经纬度数据
%    loe=119;low=123;                     %自定义经度范围
%     las=32;lan=37;                      %自定义纬度范围
    loe=118.3;low=119.9;                     %自定义经度范围
    las=33.85;lan=35.2;                      %自定义纬度范围

data4=data_area3(:,2);data5=reshape(data4,sizedata(1),sizedata(2))';%sst6=rot90(sst5,2);
m_proj('mercator','long',[loe low],'lat',[las lan]);      %矩形投影；
m_grid('box','on','tickdir','off','fontsize',16,'Fontname','Time New Roman',...
      'fontweight','bold','ytick',4,'xtick',4);hold on;

m_pcolor(X,Y,data5');  %Makes a pcolor image on a map.
shading interp; 
hold on;
 colormap(turbo);
%m_gshhs_f('patch',[0.5 0.5 0.5],'EdgeColor','k','LineWidth',1.2);
% colormap(colormap_sio);
% cLim = [min(yTick(:)) max(yTick(:))];

shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市';
S = m_shaperead(shapefile);

% 遍历每个多边形（城市边界）
for i = 1:length(S.ncst)
    coords = S.ncst{i}; % 获取第 i 个城市的坐标
    % 绘制边界
    m_plot(coords(:,1), coords(:,2), 'k', 'LineWidth', 1); % 黑色边界，线宽 1.5
    hold on; % 确保不会覆盖之前的绘制
end


hBar = colorbar;
 clim([-0.01 0.02]);
set(hBar,'Fontsize',12,'Fontname','Time New Roman');
set(get(hBar, 'Title'), 'string', '', 'Fontsize', 16, 'Fontname', 'Times New Roman');
% title(hBar, '(μg/m³)', 'FontSize', 16, 'FontName', 'Times New Roman');
title('EOF2 9.8%', 'FontSize', 16, 'FontName', 'Times New Roman');


