%%
figure
y0 = 0;
x0 = 1:timedata;
x1 = 1:timedata;
t1 = timef(:,1);

% 计算每个模态的均值和标准差
meanTimeCoeffs = mean(t1); % 沿行方向计算均值
stdTimeCoeffs = std(t1, 0); % 沿行方向计算标准差

% 标准化处理时间系数
normalizedTimeCoeffs = (t1 - meanTimeCoeffs) ./ stdTimeCoeffs;
hold on;
h1_1 = plot(x0,y0,'k:','linewidth',1.0);     %0线
h1_2 = plot(x1,normalizedTimeCoeffs,'b--','linewidth',2.0);    %时间序列
xlabel('年份(yr)');
ylabel('时间权系数');
title('Sea-air temperature difference of autumn PC1');

figure
y0 = 0;
x0 = 1:timedata;
x1 = 1:timedata;
t1 = timef(:,2);

% 计算每个模态的均值和标准差
meanTimeCoeffs = mean(t1); % 沿行方向计算均值
stdTimeCoeffs = std(t1, 0); % 沿行方向计算标准差

% 标准化处理时间系数
normalizedTimeCoeffs = (t1 - meanTimeCoeffs) ./ stdTimeCoeffs;
hold on;
h1_1 = plot(x0,y0,'k:','linewidth',1.0);     %0线
h1_2 = plot(x1,normalizedTimeCoeffs,'b--','linewidth',2.0);    %时间序列
xlabel('年份(yr)');
ylabel('时间权系数');
title('Sea-air temperature difference of autumn PC1');

figure
y0 = 0;
x0 = 1:timedata;
x1 = 1:timedata;
t1 = timef(:,3);

% 计算每个模态的均值和标准差
meanTimeCoeffs = mean(t1); % 沿行方向计算均值
stdTimeCoeffs = std(t1, 0); % 沿行方向计算标准差

% 标准化处理时间系数
normalizedTimeCoeffs = (t1 - meanTimeCoeffs) ./ stdTimeCoeffs;
hold on;
h1_1 = plot(x0,y0,'k:','linewidth',1.0);     %0线
h1_2 = plot(x1,normalizedTimeCoeffs,'b--','linewidth',2.0);    %时间序列
xlabel('年份(yr)');
ylabel('时间权系数');
title('Sea-air temperature difference of autumn PC1');

