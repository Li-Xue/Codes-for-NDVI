% %% XZX1
% clc; clear;
% 
% % 读取数据
% [zxz, R] = readgeoraster('D:\\LYGNDVI\\zxz.tif');
% 
% % 将 sig 中为 0 的值设置为 NaN
% zxz(zxz == 0) = nan;
% 
% % 仅保留数据值 2 和 3
% zxz(~ismember(zxz, [2, 3])) = nan;
% 
% % 自定义颜色映射矩阵
% customColormap = [
%     0.5, 1, 0;   % 轻微改善（浅绿色）
%     1, 1, 0      % 稳定不变（黄色）
% ];
% 
% % 获取数据的大小
% [rows, cols] = size(zxz);
% 
% % 创建经纬度网格
% lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
% lon = linspace(R.LongitudeLimits(1), R.LatitudeLimits(2), cols);
% [lon, lat] = meshgrid(lon, lat);
% 
% % 绘制 pcolor 图
% figure;
% pcolor(lon, lat, rot90(zxz,2));
% shading flat;  % 使用平坦着色
% 
% % 应用自定义颜色图
% colormap(customColormap);
% clim([2, 3]);  % 仅映射到 2 和 3 的范围
% 
% % 绘制图例
% hold on;
% legendLabels = {'','轻微改善', '稳定不变'};
% for i = 1:2
%     plot(nan, nan, 'color', customColormap(i, :), 'linewidth', 10);  % 隐藏占位符
% end
% legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');
% 
% % 读取连云港市的 shp 文件
% shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
% Lianyungang = readgeotable(shapefile);
% 
% % 绘制连云港市的边界叠加在栅格数据上
% geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
% 
% % 设置坐标轴、字体和背景
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);
% xtickformat('degrees');
% ytickformat('degrees');
% set(gca, 'LineWidth', 2);
% set(gcf, 'Color', 'w');
%% 2000-2023
%% XZX2
clc; clear;

% 读取数据
[zxz, R] = readgeoraster('D:\\LYGNDVI\\zxz.tif');

% 将 sig 中为 0 的值设置为 NaN
zxz(zxz == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
   
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    
];

% 获取数据的大小
[rows, cols] = size(zxz);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(zxz));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'', '轻微改善', '稳定不变'};
for i = 1:2
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');
%% 在左下角添加饼状图（轻微改善和稳定不变的占比分析）
% 计算各类别的像素数
validData = zxz(~isnan(zxz));
count_class1 = sum(validData == 2);  % 轻微改善的像素数
count_class2 = sum(validData == 3);  % 稳定不变的像素数
total = count_class1 + count_class2;

% 计算占比
if total > 0
    percentages = [count_class1, count_class2] / total * 100;
else
    percentages = [0, 0];
end

% 创建饼图的子坐标轴（左下角）
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

% 绘制饼图，使用与主图相同的颜色
h_pie = pie(ax_pie, percentages);

% 设置饼图颜色（与主图一致）
h_pie(1).FaceColor = customColormap(1, :);  % 轻微改善（浅绿色）
h_pie(3).FaceColor = customColormap(2, :);  % 稳定不变（黄色）

% 添加百分比标签
h_pie(2).String = sprintf('%.1f%%', percentages(1));  % 轻微改善的百分比
h_pie(4).String = sprintf('%.1f%%', percentages(2));  % 稳定不变的百分比

% 设置标签字体
set([h_pie(2), h_pie(4)], 'FontName', 'Times New Roman', 'FontSize', 10);

% 隐藏饼图坐标轴
axis(ax_pie, 'off');

%% 2000-2003
%% XZX2
clc; clear;

% 读取数据
[zxz, R] = readgeoraster('D:\\LYGNDVI\\zxz2000.tif');

% 将 sig 中为 0 的值设置为 NaN
zxz(zxz == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
   
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    
];

% 获取数据的大小
[rows, cols] = size(zxz);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(zxz));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'', '轻微改善', '稳定不变'};
for i = 1:2
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');
%% 在左下角添加饼状图（轻微改善和稳定不变的占比分析）
% 计算各类别的像素数
validData = zxz(~isnan(zxz));
count_class1 = sum(validData == 2);  % 轻微改善的像素数
count_class2 = sum(validData == 3);  % 稳定不变的像素数
total = count_class1 + count_class2;

% 计算占比
if total > 0
    percentages = [count_class1, count_class2] / total * 100;
else
    percentages = [0, 0];
end

% 创建饼图的子坐标轴（左下角）
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

% 绘制饼图，使用与主图相同的颜色
h_pie = pie(ax_pie, percentages);

% 设置饼图颜色（与主图一致）
h_pie(1).FaceColor = customColormap(1, :);  % 轻微改善（浅绿色）
h_pie(3).FaceColor = customColormap(2, :);  % 稳定不变（黄色）

% 添加百分比标签
h_pie(2).String = sprintf('%.1f%%', percentages(1));  % 轻微改善的百分比
h_pie(4).String = sprintf('%.1f%%', percentages(2));  % 稳定不变的百分比

% 设置标签字体
set([h_pie(2), h_pie(4)], 'FontName', 'Times New Roman', 'FontSize', 10);

% 隐藏饼图坐标轴
axis(ax_pie, 'off');
%% 2004-2013
%% XZX2
clc; clear;

% 读取数据
[zxz, R] = readgeoraster('D:\\LYGNDVI\\zxz2004.tif');

% 将 sig 中为 0 的值设置为 NaN
zxz(zxz == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
   
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    
];

% 获取数据的大小
[rows, cols] = size(zxz);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(zxz));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'', '轻微改善', '稳定不变'};
for i = 1:2
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');
%% 在左下角添加饼状图（轻微改善和稳定不变的占比分析）
% 计算各类别的像素数
validData = zxz(~isnan(zxz));
count_class1 = sum(validData == 2);  % 轻微改善的像素数
count_class2 = sum(validData == 3);  % 稳定不变的像素数
total = count_class1 + count_class2;

% 计算占比
if total > 0
    percentages = [count_class1, count_class2] / total * 100;
else
    percentages = [0, 0];
end

% 创建饼图的子坐标轴（左下角）
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

% 绘制饼图，使用与主图相同的颜色
h_pie = pie(ax_pie, percentages);

% 设置饼图颜色（与主图一致）
h_pie(1).FaceColor = customColormap(1, :);  % 轻微改善（浅绿色）
h_pie(3).FaceColor = customColormap(2, :);  % 稳定不变（黄色）

% 添加百分比标签
h_pie(2).String = sprintf('%.1f%%', percentages(1));  % 轻微改善的百分比
h_pie(4).String = sprintf('%.1f%%', percentages(2));  % 稳定不变的百分比

% 设置标签字体
set([h_pie(2), h_pie(4)], 'FontName', 'Times New Roman', 'FontSize', 10);

% 隐藏饼图坐标轴
axis(ax_pie, 'off');
%% 2014-2023
%% XZX2
clc; clear;

% 读取数据
[zxz, R] = readgeoraster('D:\\LYGNDVI\\zxz2014.tif');

% 将 sig 中为 0 的值设置为 NaN
zxz(zxz == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
   
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    
];

% 获取数据的大小
[rows, cols] = size(zxz);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(zxz));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'', '轻微改善', '稳定不变'};
for i = 1:2
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');
%% 在左下角添加饼状图（轻微改善和稳定不变的占比分析）
% 计算各类别的像素数
validData = zxz(~isnan(zxz));
count_class1 = sum(validData == 2);  % 轻微改善的像素数
count_class2 = sum(validData == 3);  % 稳定不变的像素数
total = count_class1 + count_class2;

% 计算占比
if total > 0
    percentages = [count_class1, count_class2] / total * 100;
else
    percentages = [0, 0];
end

% 创建饼图的子坐标轴（左下角）
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

% 绘制饼图，使用与主图相同的颜色
h_pie = pie(ax_pie, percentages);

% 设置饼图颜色（与主图一致）
h_pie(1).FaceColor = customColormap(1, :);  % 轻微改善（浅绿色）
h_pie(3).FaceColor = customColormap(2, :);  % 稳定不变（黄色）

% 添加百分比标签
h_pie(2).String = sprintf('%.1f%%', percentages(1));  % 轻微改善的百分比
h_pie(4).String = sprintf('%.1f%%', percentages(2));  % 稳定不变的百分比

% 设置标签字体
set([h_pie(2), h_pie(4)], 'FontName', 'Times New Roman', 'FontSize', 10);

% 隐藏饼图坐标轴
axis(ax_pie, 'off');