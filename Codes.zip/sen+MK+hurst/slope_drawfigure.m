%% slope
clc; clear;

% 读取数据
[slope, R] = readgeoraster('D:\LYGNDVI\slope.tif');

% 将 slope 中为 0 的值设置为 NaN
slope(slope == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(slope);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(slope));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
 clim([-0.02, 0.02]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.02, 0.02];
c.TickLabels = {'Low: −0.02', 'High: 0.02'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽


%% sig
clc; clear;

% 读取数据
[sig, R] = readgeoraster('D:\\LYGNDVI\\sig.tif');

% 将 sig 中为 0 的值设置为 NaN
sig(sig == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
    0, 0.5, 0;   % 极显著增加（绿色）Extremely significant increase
    0.5, 1, 0;   % 显著增加（浅绿色）significant increase
    1, 1, 0;     % 稳定（黄色）stability
    1, 0.5, 0;   % 显著减少（浅橙色）significant reduction
    1, 0, 0      % 极显著减少（红色）Extremely significant reduction
];

% 获取数据的大小
[rows, cols] = size(sig);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sig));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'','极显著增加', '显著增加', '稳定', '显著减少', '极显著减少'};
for i = 1:5
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');

%% slope2014
clc; clear;

% 读取数据
[slope, R] = readgeoraster('D:\LYGNDVI\slope2014.tif');

% 将 slope 中为 0 的值设置为 NaN
slope(slope == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(slope);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(slope));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
 clim([-0.06, 0.02]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.06, 0.02];
c.TickLabels = {'Low: −0.06', 'High: 0.02'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽


%% sig2014
%unique_values = unique(sig(~isnan(sig)));
%disp(unique_values);


clc; clear;

% 读取数据
[sig, R] = readgeoraster('D:\\LYGNDVI\\sig2014.tif');

% 将 sig 中为 0 的值设置为 NaN
sig(sig == 0) = nan;

% 自定义颜色映射矩阵 - 只保留三种分类：稳定、显著减少、极显著减少
customColormap = [
    0.5, 1, 0;     % 稳定（绿色）
    1, 1, 0;   % 显著减少（黄色）
    1, 0, 0      % 极显著减少（红色）
];

% 获取数据的大小
[rows, cols] = size(sig);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sig));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 设置为自定义的三种颜色

% 设置颜色范围 - 将数据值映射到三种分类
clim([3 5]);  % 假设0-1为稳定，1-2为显著减少，2-3为极显著减少

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
legendLabels = {'','稳定', '显著减少', '极显著减少'};
for i = 1:3
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为宋体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');