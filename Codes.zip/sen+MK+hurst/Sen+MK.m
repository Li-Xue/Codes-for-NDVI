%% 2000-2023
clear;clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 24; % 时间序列长度

datasum = NaN(m * n, num);
% 循环读取每一年的数据
for year = 2000:2023
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    % filename = sprintf('C:\\Users\\HL\\Desktop\\fvc\\data\\fvc%d.tif', year);
    data = reshape(importdata(filename), m * n, 1);
    datasum(:, year - 1999) = data; % 1999这个值是初始年份减去1得到
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

% sen趋势运算变量
sen = NaN(m, n);
min_data = min(datasum, [], 2) > 0;

% mk检验运算变量
sresult = NaN(m, n);
mk = NaN(m, n);

for i = 1:m*n
    % sen趋势计算过程
    if min_data(i)
        valuesum = [];
        for k1 = 2:num
            for k2 = 1:(k1 - 1)
                cz = datasum(i, k1) - datasum(i, k2);
                jl = k1 - k2;
                value = cz / jl;
                valuesum = [valuesum; value];
            end
        end
        sen(i) = median(valuesum);
    end
    
    % mk趋势检验计算过程
    data = datasum(i, :);
    validPoints = data > 0;

    % 向量化mk
    sgnsum = bsxfun(@minus, data(2:end), data(1:end-1));
    sgnsum = sign(sgnsum);
    sgnsum(sgnsum == 0) = 0;

    add = sum(sgnsum(:));
    sresult(i) = add * validPoints(1);
end

% 仅处理有效值，其余设为0
sen(~min_data) = 0;

% mk标准化统计量
vars = num * (num - 1) * (2 * num + 5) / 18;
mk = zeros(m, n);
mk(sresult == 0) = 0;
mk(sresult > 0) = (sresult(sresult > 0) - 1) ./ sqrt(vars);
mk(sresult < 0) = (sresult(sresult < 0) + 1) ./ sqrt(vars);

% 显著性：明显改善1，轻微改善2，稳定不变3，轻微退化4，严重退化5  
xzx = zeros(m,n);
for i = 1:m
    for j = 1:n
        % 明显改善：sen >= 0.0005 且 |mk| >= 1.96
        if sen(i,j) >= 0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 1;
        % 轻微改善：sen >= 0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) >= 0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 2;
        % 稳定不变：-0.0005 < sen < 0.0005
        elseif -0.0005 < sen(i,j) < 0.0005
            xzx(i,j) = 3;
        % 轻微退化：sen <= -0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) <= -0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 4;
        % 严重退化：sen <= -0.0005 且 |mk| >= 1.96
        elseif sen(i,j) <= -0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 5;
        end
    end
end

filename1 = 'D:\\LYGNDVI\\sen.tif';
filename2 = 'D:\\LYGNDVI\\mk.tif';
filename3 = 'D:\\LYGNDVI\\zxz.tif';
geotiffwrite(filename1, sen, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename2, mk, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename3, xzx, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2000-2003
clear;clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 4; % 时间序列长度

datasum = NaN(m * n, num);
% 循环读取每一年的数据
for year = 2000:2003
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    % filename = sprintf('C:\\Users\\HL\\Desktop\\fvc\\data\\fvc%d.tif', year);
    data = reshape(importdata(filename), m * n, 1);
    datasum(:, year - 1999) = data; % 1999这个值是初始年份减去1得到
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

% sen趋势运算变量
sen = NaN(m, n);
min_data = min(datasum, [], 2) > 0;

% mk检验运算变量
sresult = NaN(m, n);
mk = NaN(m, n);

for i = 1:m*n
    % sen趋势计算过程
    if min_data(i)
        valuesum = [];
        for k1 = 2:num
            for k2 = 1:(k1 - 1)
                cz = datasum(i, k1) - datasum(i, k2);
                jl = k1 - k2;
                value = cz / jl;
                valuesum = [valuesum; value];
            end
        end
        sen(i) = median(valuesum);
    end
    
    % mk趋势检验计算过程
    data = datasum(i, :);
    validPoints = data > 0;

    % 向量化mk
    sgnsum = bsxfun(@minus, data(2:end), data(1:end-1));
    sgnsum = sign(sgnsum);
    sgnsum(sgnsum == 0) = 0;

    add = sum(sgnsum(:));
    sresult(i) = add * validPoints(1);
end

% 仅处理有效值，其余设为0
sen(~min_data) = 0;

% mk标准化统计量
vars = num * (num - 1) * (2 * num + 5) / 18;
mk = zeros(m, n);
mk(sresult == 0) = 0;
mk(sresult > 0) = (sresult(sresult > 0) - 1) ./ sqrt(vars);
mk(sresult < 0) = (sresult(sresult < 0) + 1) ./ sqrt(vars);

% 显著性：明显改善1，轻微改善2，稳定不变3，轻微退化4，严重退化5  
xzx = zeros(m,n);
for i = 1:m
    for j = 1:n
        % 明显改善：sen >= 0.0005 且 |mk| >= 1.96
        if sen(i,j) >= 0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 1;
        % 轻微改善：sen >= 0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) >= 0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 2;
        % 稳定不变：-0.0005 < sen < 0.0005
        elseif -0.0005 < sen(i,j) < 0.0005
            xzx(i,j) = 3;
        % 轻微退化：sen <= -0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) <= -0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 4;
        % 严重退化：sen <= -0.0005 且 |mk| >= 1.96
        elseif sen(i,j) <= -0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 5;
        end
    end
end

filename1 = 'D:\\LYGNDVI\\sen2000.tif';
filename2 = 'D:\\LYGNDVI\\mk2000.tif';
filename3 = 'D:\\LYGNDVI\\zxz2000.tif';
geotiffwrite(filename1, sen, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename2, mk, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename3, xzx, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
%% 2004-2013
clear;clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 10; % 时间序列长度

datasum = NaN(m * n, num);
% 循环读取每一年的数据
for year = 2004:2013
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    % filename = sprintf('C:\\Users\\HL\\Desktop\\fvc\\data\\fvc%d.tif', year);
    data = reshape(importdata(filename), m * n, 1);
    datasum(:, year - 2003) = data; % 1999这个值是初始年份减去1得到
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

% sen趋势运算变量
sen = NaN(m, n);
min_data = min(datasum, [], 2) > 0;

% mk检验运算变量
sresult = NaN(m, n);
mk = NaN(m, n);

for i = 1:m*n
    % sen趋势计算过程
    if min_data(i)
        valuesum = [];
        for k1 = 2:num
            for k2 = 1:(k1 - 1)
                cz = datasum(i, k1) - datasum(i, k2);
                jl = k1 - k2;
                value = cz / jl;
                valuesum = [valuesum; value];
            end
        end
        sen(i) = median(valuesum);
    end
    
    % mk趋势检验计算过程
    data = datasum(i, :);
    validPoints = data > 0;

    % 向量化mk
    sgnsum = bsxfun(@minus, data(2:end), data(1:end-1));
    sgnsum = sign(sgnsum);
    sgnsum(sgnsum == 0) = 0;

    add = sum(sgnsum(:));
    sresult(i) = add * validPoints(1);
end

% 仅处理有效值，其余设为0
sen(~min_data) = 0;

% mk标准化统计量
vars = num * (num - 1) * (2 * num + 5) / 18;
mk = zeros(m, n);
mk(sresult == 0) = 0;
mk(sresult > 0) = (sresult(sresult > 0) - 1) ./ sqrt(vars);
mk(sresult < 0) = (sresult(sresult < 0) + 1) ./ sqrt(vars);

% 显著性：明显改善1，轻微改善2，稳定不变3，轻微退化4，严重退化5  
xzx = zeros(m,n);
for i = 1:m
    for j = 1:n
        % 明显改善：sen >= 0.0005 且 |mk| >= 1.96
        if sen(i,j) >= 0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 1;
        % 轻微改善：sen >= 0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) >= 0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 2;
        % 稳定不变：-0.0005 < sen < 0.0005
        elseif -0.0005 < sen(i,j) < 0.0005
            xzx(i,j) = 3;
        % 轻微退化：sen <= -0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) <= -0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 4;
        % 严重退化：sen <= -0.0005 且 |mk| >= 1.96
        elseif sen(i,j) <= -0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 5;
        end
    end
end

filename1 = 'D:\\LYGNDVI\\sen2004.tif';
filename2 = 'D:\\LYGNDVI\\mk2004.tif';
filename3 = 'D:\\LYGNDVI\\zxz2004.tif';
geotiffwrite(filename1, sen, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename2, mk, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename3, xzx, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2014-2023
clear;clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 10; % 时间序列长度

datasum = NaN(m * n, num);
% 循环读取每一年的数据
for year = 2014:2013
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    % filename = sprintf('C:\\Users\\HL\\Desktop\\fvc\\data\\fvc%d.tif', year);
    data = reshape(importdata(filename), m * n, 1);
    datasum(:, year - 2013) = data; % 1999这个值是初始年份减去1得到
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

% sen趋势运算变量
sen = NaN(m, n);
min_data = min(datasum, [], 2) > 0;

% mk检验运算变量
sresult = NaN(m, n);
mk = NaN(m, n);

for i = 1:m*n
    % sen趋势计算过程
    if min_data(i)
        valuesum = [];
        for k1 = 2:num
            for k2 = 1:(k1 - 1)
                cz = datasum(i, k1) - datasum(i, k2);
                jl = k1 - k2;
                value = cz / jl;
                valuesum = [valuesum; value];
            end
        end
        sen(i) = median(valuesum);
    end
    
    % mk趋势检验计算过程
    data = datasum(i, :);
    validPoints = data > 0;

    % 向量化mk
    sgnsum = bsxfun(@minus, data(2:end), data(1:end-1));
    sgnsum = sign(sgnsum);
    sgnsum(sgnsum == 0) = 0;

    add = sum(sgnsum(:));
    sresult(i) = add * validPoints(1);
end

% 仅处理有效值，其余设为0
sen(~min_data) = 0;

% mk标准化统计量
vars = num * (num - 1) * (2 * num + 5) / 18;
mk = zeros(m, n);
mk(sresult == 0) = 0;
mk(sresult > 0) = (sresult(sresult > 0) - 1) ./ sqrt(vars);
mk(sresult < 0) = (sresult(sresult < 0) + 1) ./ sqrt(vars);

% 显著性：明显改善1，轻微改善2，稳定不变3，轻微退化4，严重退化5  
xzx = zeros(m,n);
for i = 1:m
    for j = 1:n
        % 明显改善：sen >= 0.0005 且 |mk| >= 1.96
        if sen(i,j) >= 0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 1;
        % 轻微改善：sen >= 0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) >= 0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 2;
        % 稳定不变：-0.0005 < sen < 0.0005
        elseif -0.0005 < sen(i,j) < 0.0005
            xzx(i,j) = 3;
        % 轻微退化：sen <= -0.0005 且 -1.96 < mk < 1.96
        elseif sen(i,j) <= -0.0005 && -1.96 < mk(i,j) < 1.96
            xzx(i,j) = 4;
        % 严重退化：sen <= -0.0005 且 |mk| >= 1.96
        elseif sen(i,j) <= -0.0005 && abs(mk(i,j)) >= 1.96
            xzx(i,j) = 5;
        end
    end
end

filename1 = 'D:\\LYGNDVI\\sen2014.tif';
filename2 = 'D:\\LYGNDVI\\mk2014.tif';
filename3 = 'D:\\LYGNDVI\\zxz2014.tif';
geotiffwrite(filename1, sen, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename2, mk, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite(filename3, xzx, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);