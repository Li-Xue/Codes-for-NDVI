%%  2000-2023
%% sen
clc; clear;

% 读取数据
[sen, R] = readgeoraster('D:\\LYGNDVI\\sen.tif');

% 将 slope 中为 0 的值设置为 NaN
sen(sen == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(sen);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sen));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
clim([-0.025, 0.025]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.025, 0.025];
c.TickLabels = {'Low: −0.025', 'High: 0.025'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽



%% 2000-2003
%% sen
clc; clear;

% 读取数据
[sen, R] = readgeoraster('D:\\LYGNDVI\\sen2000.tif');

% 将 slope 中为 0 的值设置为 NaN
sen(sen == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(sen);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sen));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
clim([-0.05, 0.05]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.05, 0.05];
c.TickLabels = {'Low: −0.05', 'High: 0.05'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽






%% 2004-2013
%% sen
clc; clear;

% 读取数据
[sen, R] = readgeoraster('D:\\LYGNDVI\\sen2004.tif');

% 将 slope 中为 0 的值设置为 NaN
sen(sen == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(sen);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sen));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
clim([-0.06, 0.06]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.06, 0.06];
c.TickLabels = {'Low: −0.06', 'High: 0.06'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽





%% 2014-2023
%% sen
clc; clear;

% 读取数据
[sen, R] = readgeoraster('D:\\LYGNDVI\\sen2014.tif');

% 将 slope 中为 0 的值设置为 NaN
sen(sen == 0) = nan;

% 自定义渐变色彩条（绿色-黄色-红色）
customColormap = [
    linspace(0, 1, 100)', linspace(0.5, 1, 100)', linspace(0, 0, 100)'; % 从绿色到黄色
    linspace(1, 1, 100)', linspace(1, 0, 100)', linspace(0, 0, 100)'   % 从黄色到红色
];

% 获取数据的大小
[rows, cols] = size(sen);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(sen));
shading interp;  % 使用平滑着色

% 自定义颜色图
colormap([1 1 1; customColormap]);  % 将 NaN 显示为白色

% 设置图的显示位置和大小
ax = gca;
ax.Position = [0.14, 0.14, 0.6, 0.8];  % [left, bottom, width, height]，设置图的位置和宽度

% 添加 colorbar
c = colorbar('eastoutside');  % 将 colorbar 放在图的右边（外侧）
clim([-0.04, 0.04]);  % 设置数据范围

% 设置 colorbar 的标签格式
c.Ticks = [-0.04, 0.04];
c.TickLabels = {'Low: −0.04', 'High: 0.04'};


% 调整 colorbar 的位置和高度
c.Position(1) = 0.54 ;  % 将 colorbar 向右移动，增加图和 colorbar 之间的间距
c.Position(2) = 0.75;   % 调整 colorbar 的垂直位置
c.Position(4) = 0.1;   % 设置 colorbar 的高度，使之缩小

% 去掉 colorbar 的边框框线并设置背景色
c.Box = 'off';
set(gcf, 'Color', 'w');  % 设置整个图背景为白色，避免边框显著

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
hold on;
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);
hold off;

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 获取当前的经纬度刻度
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

% 修改刻度标签，添加 N 和 E 后缀
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);


% 设置坐标轴的坐标范围，留出边距空间
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围


% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽


