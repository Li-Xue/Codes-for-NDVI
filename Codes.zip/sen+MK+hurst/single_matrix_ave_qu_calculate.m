%% NDVI平均值
clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 24; % 时间序列长度

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2000:2023
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 1999) = data; % 直接存储到三维数组
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

NDVI=nanmean(datasum,3);

[rows, cols] = size(NDVI);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[X, Y] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 读取shapefile
S = shaperead('D:\连云港大气污染\shp\output\连云港市.shp');

% 初始化统计结果保存结构
stats = struct('County', {}, 'MaxNDVI', {}, 'MinNDVI', {}, 'MeanNDVI', {});

% 遍历每个县区
for i = 1:length(S)
    % 获取当前县区的边界
    county_shape = S(i);
    
    % 创建一个逻辑矩阵来标识NDVI矩阵中属于当前县区的像元
    % 假设您有一个经纬度到像元索引的映射，需要使用适当的方法
    % 这一步需要您定义（根据您的NDVI坐标和shapefile坐标系统）
    mask = inpolygon(X, Y, county_shape.X, county_shape.Y);  % X, Y 是 NDVI 矩阵的坐标矩阵
    
    % 提取属于该县区的NDVI值
    ndvi_values = NDVI(mask);
    
    % 统计最大、最小和平均值
    stats(i).County = county_shape.name;  % 假设shapefile中有一个名为Name的字段
    stats(i).MaxNDVI = max(ndvi_values, [], 'omitnan');   % 最大值
    stats(i).MinNDVI = min(ndvi_values, [], 'omitnan');   % 最小值
    stats(i).MeanNDVI = mean(ndvi_values, 'omitnan');      % 平均值
end

% 将结果存储为表格并显示
results_table = struct2table(stats);
disp(results_table);

%% CV变异系数

clc; clear;

% subplot(1, 2, 2);
% 读取数据
[CV, R] = readgeoraster('D:\\LYGNDVI\\CV.tif');

% 将 slope 中为 0 的值设置为 NaN
CV(CV == 0) = nan;

mincv=min(reshape(CV,1,459*568));
maxcv=max(reshape(CV,1,459*568));
meancv=nanmean(reshape(CV,1,459*568));

[rows, cols] = size(CV);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[X, Y] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 读取shapefile
S = shaperead('D:\连云港大气污染\shp\output\连云港市.shp');

% 初始化统计结果保存结构
stats = struct('County', {}, 'MaxNDVI', {}, 'MinNDVI', {}, 'MeanNDVI', {});

% 遍历每个县区
for i = 1:length(S)
    % 获取当前县区的边界
    county_shape = S(i);
    
    % 创建一个逻辑矩阵来标识NDVI矩阵中属于当前县区的像元
    % 假设您有一个经纬度到像元索引的映射，需要使用适当的方法
    % 这一步需要您定义（根据您的NDVI坐标和shapefile坐标系统）
    mask = inpolygon(X, Y, county_shape.X, county_shape.Y);  % X, Y 是 NDVI 矩阵的坐标矩阵
    
    % 提取属于该县区的NDVI值
    ndvi_values = CV(mask);
    
    % 统计最大、最小和平均值
    stats(i).County = county_shape.name;  % 假设shapefile中有一个名为Name的字段
    stats(i).MaxNDVI = max(ndvi_values, [], 'omitnan');   % 最大值
    stats(i).MinNDVI = min(ndvi_values, [], 'omitnan');   % 最小值
    stats(i).MeanNDVI = mean(ndvi_values, 'omitnan');      % 平均值
end

% 将结果存储为表格并显示
results_table = struct2table(stats);
disp(results_table);

% 0.25值统计占比
data_matrix=data5;

% 计算小于0.25的元素的比例（忽略NaN）
% 统计总像素数（非NaN元素）
total_count = numel(data_matrix);  % 矩阵的总元素数
valid_count = sum(~isnan(data_matrix(:)));  % 有效（非NaN）元素数

% 计算小于0.25的元素
count_less_than_025 = sum(data_matrix(:) < 0 & ~isnan(data_matrix(:)));  % 小于0.25的有效元素数

% 计算小于0.25的占比
percentage_less_than_025 = (count_less_than_025 / valid_count) * 100;  % 占比

% 打印结果
fprintf('小于0.25的数据占比: %.2f%%\n', percentage_less_than_025);


%%  slope
% 读取数据
[slope, R] = readgeoraster('D:\LYGNDVI\slope.tif');

% 将 slope 中为 0 的值设置为 NaN
slope(slope == 0) = nan;

minslope=min(reshape(slope,1,459*568));
maxslope=max(reshape(slope,1,459*568));
meanslope=nanmean(reshape(slope,1,459*568));

[rows, cols] = size(slope);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[X, Y] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 读取shapefile
S = shaperead('D:\连云港大气污染\shp\output\连云港市.shp');

% 初始化统计结果保存结构
stats = struct('County', {}, 'MaxNDVI', {}, 'MinNDVI', {}, 'MeanNDVI', {});

% 遍历每个县区
for i = 1:length(S)
    % 获取当前县区的边界
    county_shape = S(i);
    
    % 创建一个逻辑矩阵来标识NDVI矩阵中属于当前县区的像元
    % 假设您有一个经纬度到像元索引的映射，需要使用适当的方法
    % 这一步需要您定义（根据您的NDVI坐标和shapefile坐标系统）
    mask = inpolygon(X, Y, county_shape.X, county_shape.Y);  % X, Y 是 NDVI 矩阵的坐标矩阵
    
    % 提取属于该县区的NDVI值
    ndvi_values = slope(mask);
    
    % 统计最大、最小和平均值
    stats(i).County = county_shape.name;  % 假设shapefile中有一个名为Name的字段
    stats(i).MaxNDVI = max(ndvi_values, [], 'omitnan');   % 最大值
    stats(i).MinNDVI = min(ndvi_values, [], 'omitnan');   % 最小值
    stats(i).MeanNDVI = mean(ndvi_values, 'omitnan');      % 平均值
end

 % 0.25值统计占比
data_matrix=slope;

% 计算小于0.25的元素的比例（忽略NaN）
% 统计总像素数（非NaN元素）
total_count = numel(data_matrix);  % 矩阵的总元素数
valid_count = sum(~isnan(data_matrix(:)));  % 有效（非NaN）元素数

% 计算小于0.25的元素
count_less_than_025 = sum(data_matrix(:) > 0 & ~isnan(data_matrix(:)));  % 小于0.25的有效元素数

% 计算小于0.25的占比
percentage_less_than_025 = (count_less_than_025 / valid_count) * 100;  % 占比

% 打印结果
fprintf('小于0.25的数据占比: %.2f%%\n', percentage_less_than_025);

%% hurst
clc; clear;

% 读取数据
[hurst, R] = readgeoraster('D:\\LYGNDVI\\hurst.tif');

% 将 hurst 中为 0 的值设置为 NaN
hurst(hurst == 0) = nan;
hurst(hurst >1 ) = nan;

minhurst=min(reshape(hurst,1,459*568));
maxhurst=max(reshape(hurst,1,459*568));
meanhurst=nanmean(reshape(hurst,1,459*568));

[rows, cols] = size(hurst);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[X, Y] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 读取shapefile
S = shaperead('D:\连云港大气污染\shp\output\连云港市.shp');

% 初始化统计结果保存结构
stats = struct('County', {}, 'MaxNDVI', {}, 'MinNDVI', {}, 'MeanNDVI', {});

% 遍历每个县区
for i = 1:length(S)
    % 获取当前县区的边界
    county_shape = S(i);
    
    % 创建一个逻辑矩阵来标识NDVI矩阵中属于当前县区的像元
    % 假设您有一个经纬度到像元索引的映射，需要使用适当的方法
    % 这一步需要您定义（根据您的NDVI坐标和shapefile坐标系统）
    mask = inpolygon(X, Y, county_shape.X, county_shape.Y);  % X, Y 是 NDVI 矩阵的坐标矩阵
    
    % 提取属于该县区的NDVI值
    ndvi_values = hurst(mask);
    
    % 统计最大、最小和平均值
    stats(i).County = county_shape.name;  % 假设shapefile中有一个名为Name的字段
    stats(i).MaxNDVI = max(ndvi_values, [], 'omitnan');   % 最大值
    stats(i).MinNDVI = min(ndvi_values, [], 'omitnan');   % 最小值
    stats(i).MeanNDVI = mean(ndvi_values, 'omitnan');      % 平均值
end


 % 0.25值统计占比
data_matrix=hurst;

% 计算小于0.25的元素的比例（忽略NaN）
% 统计总像素数（非NaN元素）
total_count = numel(data_matrix);  % 矩阵的总元素数
valid_count = sum(~isnan(data_matrix(:)));  % 有效（非NaN）元素数

% 计算小于0.25的元素
count_less_than_025 = sum(data_matrix(:) > 1 & ~isnan(data_matrix(:)));  % 小于0.25的有效元素数

% 计算小于0.25的占比
percentage_less_than_025 = (count_less_than_025 / valid_count) * 100;  % 占比

% 打印结果
fprintf('小于0.25的数据占比: %.2f%%\n', percentage_less_than_025);


%%

