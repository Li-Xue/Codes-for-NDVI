% 测试数据集
% data=importdata(file);
% data(data < 0) = NaN; 
% data(data == -9999) = NaN; 
% data(data == 670) = NaN; 
% data=data*0.0001;
% imagesc(data)


clc;clear;

% 加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
years = 24; % 根据需要修改

data = zeros(m * n, years);
k = 1;

for year = 2000:2023 % 根据需要修改
    file = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    bz = reshape(importdata(file), m * n, 1);
    data(:, k) = bz;
    k = k + 1;
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
data(data < 0) = NaN; 
data(data == -9999) = NaN; 
data(data == 670) = NaN; 
data=data*0.0001;

bya = zeros(m, n);

for i = 1:m * n
    bz = data(i, :);
    bz = bz';
    if min(bz) > 0
        A = mean(bz);
        S = std(bz, 1);
        V = S / A;
        bya(i) = V;
    end
end

bya = reshape(bya, m, n);
name1 = 'D:\\LYGNDVI\\CV.tif'; % 根据需要修改
geotiffwrite(name1, bya, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);