%% 统计Hurst指数四个等级（英文变量）
validData = hurst(~isnan(hurst));  % 有效数据
total = length(validData);

% 统计各等级数量
strong_anti = sum(validData > 0 & validData <= 0.25);       % 强反持续 (0 < H ≤ 0.25)
weak_anti = sum(validData > 0.25 & validData < 0.5);         % 弱反持续 (0.25 < H < 0.5)
weak_persist = sum(validData >= 0.5 & validData < 0.75);     % 弱持续 (0.5 ≤ H < 0.75)
strong_persist = sum(validData >= 0.75 & validData < 1);     % 强持续 (0.75 ≤ H < 1)

% 计算占比（保留1位小数）
percentages = [strong_anti, weak_anti, weak_persist, strong_persist] / total * 100;
percentages = round(percentages, 2);
