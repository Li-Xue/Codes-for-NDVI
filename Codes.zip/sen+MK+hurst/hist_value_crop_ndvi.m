clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 24; % 时间序列长度

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2000:2023
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 1999) = data; % 直接存储到三维数组
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;


% 定义NDVI分类阈值
% 裸地（0 ≤ NDVI < 0.1）
% 草地（0.1 ≤ NDVI < 0.3）
% 农田（0.3 ≤ NDVI < 0.5）
% 灌木（0.5 ≤ NDVI < 0.7）
% 森林（0.7 ≤ NDVI ≤ 1.0）

categories = {'Bare land', 'Grassland', 'Farmland', 'Shrubland', 'Forest'};
category_counts = zeros(num, 5); % 用于存储每年每个类别的像素计数

% 分类并统计每年的每个类别
for year_idx = 1:num
    data = datasum(:, :, year_idx);  % 当前年度数据
    
    % 分类：使用NDVI范围对数据进行分类
    bare_land = (data >= 0) & (data < 0.1);        % 裸地
    grassland = (data >= 0.1) & (data < 0.3);      % 草地
    farmland = (data >= 0.3) & (data < 0.5);       % 农田
    shrubland = (data >= 0.5) & (data < 0.7);      % 灌木
    forest = (data >= 0.7) & (data <= 1.0);        % 森林
    
    % 统计每年每个类别的像素数
    category_counts(year_idx, 1) = sum(bare_land(:), 'omitnan');   % 裸地像素数
    category_counts(year_idx, 2) = sum(grassland(:), 'omitnan');   % 草地像素数
    category_counts(year_idx, 3) = sum(farmland(:), 'omitnan');    % 农田像素数
    category_counts(year_idx, 4) = sum(shrubland(:), 'omitnan');   % 灌木像素数
    category_counts(year_idx, 5) = sum(forest(:), 'omitnan');     % 森林像素数
end

% 将统计结果转为表格
years = 2000:2023;
category_stats = array2table(category_counts, 'VariableNames', categories, 'RowNames', string(years));

% 显示表格结果
disp(category_stats);

% 可以选择将结果保存为CSV文件
writetable(category_stats, 'NDVI_category_statistics.csv', 'WriteRowNames', true);