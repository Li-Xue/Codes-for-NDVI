
clc;clear;

% 先导入某个图像的投影信息，为后续图像输出做准确
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);

years = 23; % 表示有多少年份需要做回归，根据需要修改
data = zeros(m * n, years);

for year = 2000:2022 % 起始年份，根据需要修改
    file = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    bz = importdata(file);
    data(:, year - 1999) = bz(:); % 向量化赋值
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
data(data < 0) = NaN; 
data(data == -9999) = NaN; 
data(data == 670) = NaN; 
data=data*0.0001;

xielv = zeros(m, n);
p = zeros(m, n);

trend = zeros(m, n);

for i = 1:m * n
    bz = data(i, :);
    if max(bz) > 0
        bz = bz(:);
        X = [ones(size(bz)) (1:years)'];
        [b, ~, ~, ~, stats] = regress(bz, X);
        pz = stats(3);
        p(i) = pz;
        xielv(i) = b(2);
        
        % 显著性判断
        if xielv(i) > 0
            if p(i) <= 0.01
                trend(i) = 1;%极显著增加
            elseif p(i) <= 0.05
                trend(i) = 2;%显著增加
            else
                trend(i)=3;%稳定
            end
        else
            if p(i) <= 0.01 %极显著减少
                trend(i) = 4;
            elseif p(i) <= 0.05
                trend(i) = 5;%显著减少
            else
                trend(i)=3;%稳定
            end
        end
    end
end

xielv = reshape(xielv, m, n);
p = reshape(p, m, n); % P值没有保存
trend = reshape(trend, m, n);

% 输出 GeoTIFF 文件
geotiffwrite('D:\\LYGNDVI\\slope.tif', xielv, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('D:\\LYGNDVI\\sig.tif', trend, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%%
clc;clear;

% 先导入某个图像的投影信息，为后续图像输出做准确
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);

years = 10; % 表示有多少年份需要做回归，根据需要修改
data = zeros(m * n, years);

for year = 2014:2022 % 起始年份，根据需要修改
    file = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    bz = importdata(file);
    data(:, year - 2013) = bz(:); % 向量化赋值
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
data(data < 0) = NaN; 
data(data == -9999) = NaN; 
data(data == 670) = NaN; 
data=data*0.0001;

xielv = zeros(m, n);
p = zeros(m, n);

trend = zeros(m, n);

for i = 1:m * n
    bz = data(i, :);
    if max(bz) > 0
        bz = bz(:);
        X = [ones(size(bz)) (1:years)'];
        [b, ~, ~, ~, stats] = regress(bz, X);
        pz = stats(3);
        p(i) = pz;
        xielv(i) = b(2);
        
        % 显著性判断
        if xielv(i) > 0
            if p(i) <= 0.01
                trend(i) = 1;%极显著增加
            elseif p(i) <= 0.05
                trend(i) = 2;%显著增加
            else
                trend(i)=3;%稳定
            end
        else
            if p(i) <= 0.01 %极显著减少
                trend(i) = 4;
            elseif p(i) <= 0.05
                trend(i) = 5;%显著减少
            else
                trend(i)=3;%稳定
            end
        end
    end
end

xielv = reshape(xielv, m, n);
p = reshape(p, m, n); % P值没有保存
trend = reshape(trend, m, n);

% 输出 GeoTIFF 文件
geotiffwrite('D:\\LYGNDVI\\slope2014.tif', xielv, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('D:\\LYGNDVI\\sig2014.tif', trend, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);