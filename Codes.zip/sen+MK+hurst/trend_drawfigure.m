%% trend
clc; clear;

% 读取数据
[trend, R] = readgeoraster('D:\\LYGNDVI\\trend.tif');

% 将 sig 中为 0 的值设置为 NaN
trend(trend == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
    0, 0.5, 0;   % 极显著增加（绿色）
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    1, 0.5, 0;   % 显著减少（浅橙色）
];

% 获取数据的大小
[rows, cols] = size(trend);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(trend));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'','增加—持续', '增加—反持续', '减少—持续', '减少—反持续'};
for i = 1:4
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');

% 在左下角添加饼状图（占比分析）
% 计算各类型的占比
validData = trend(~isnan(trend));
total = length(validData);
count1 = sum(validData == 1);  % 极显著增加
count2 = sum(validData == 2);  % 显著增加
count3 = sum(validData == 3);  % 稳定
count4 = sum(validData == 4);  % 显著减少
percentages = [count1, count2, count3, count4] / total * 100;

% 创建饼图的子坐标轴
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

h_pie = pie(ax_pie, percentages);  % ax_pie 是饼图的坐标区对象

% ------------- （2）设置饼图颜色与主图一致 -------------
% 只修改扇形（Patch）的颜色，跳过文本（Text）对象
patch_idx = 1:2:length(h_pie);  % 扇形对象固定在奇数索引
for i = 1:length(patch_idx)
    h_pie(patch_idx(i)).FaceColor = customColormap(i, :);  % customColormap 与主图颜色一致
end

% ------------- （4）隐藏饼图坐标轴（可选，更简洁） -------------
axis(ax_pie, 'off');
%% 2000-2003
%% trend
clc; clear;

% 读取数据
[trend, R] = readgeoraster('D:\\LYGNDVI\\trend2000.tif');

% 将 sig 中为 0 的值设置为 NaN
trend(trend == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
    0, 0.5, 0;   % 极显著增加（绿色）
    1, 1, 0;     % 稳定（黄色）
  
];

% 获取数据的大小
[rows, cols] = size(trend);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(trend));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'','增加—持续', '减少—持续'};
for i = 1:2
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');

% 在左下角添加饼状图（占比分析）
% 计算各类型的占比
validData = trend(~isnan(trend));
total = length(validData);
count1 = sum(validData == 1);  % 极显著增加
% count2 = sum(validData == 2);  % 显著增加
count3 = sum(validData == 3);  % 稳定
% count4 = sum(validData == 4);  % 显著减少
percentages = [count1, count3] / total * 100;

% 创建饼图的子坐标轴
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

h_pie = pie(ax_pie, percentages);  % ax_pie 是饼图的坐标区对象

% ------------- （2）设置饼图颜色与主图一致 -------------
% 只修改扇形（Patch）的颜色，跳过文本（Text）对象
patch_idx = 1:2:length(h_pie);  % 扇形对象固定在奇数索引
for i = 1:length(patch_idx)
    h_pie(patch_idx(i)).FaceColor = customColormap(i, :);  % customColormap 与主图颜色一致
end

% ------------- （4）隐藏饼图坐标轴（可选，更简洁） -------------
axis(ax_pie, 'off');
%% 2004-2013
%% trend
clc; clear;

% 读取数据
[trend, R] = readgeoraster('D:\\LYGNDVI\\trend2004.tif');

% 将 sig 中为 0 的值设置为 NaN
trend(trend == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
    0, 0.5, 0;   % 极显著增加（绿色）
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    1, 0.5, 0;   % 显著减少（浅橙色）
];

% 获取数据的大小
[rows, cols] = size(trend);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(trend));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'','增加—持续', '增加—反持续', '减少—持续', '减少—反持续'};
for i = 1:4
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');


% 在左下角添加饼状图（占比分析）
% 计算各类型的占比
validData = trend(~isnan(trend));
total = length(validData);
count1 = sum(validData == 1);  % 极显著增加
count2 = sum(validData == 2);  % 显著增加
count3 = sum(validData == 3);  % 稳定
count4 = sum(validData == 4);  % 显著减少
percentages = [count1, count2, count3, count4] / total * 100;

% 创建饼图的子坐标轴
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

h_pie = pie(ax_pie, percentages);  % ax_pie 是饼图的坐标区对象

% ------------- （2）设置饼图颜色与主图一致 -------------
% 只修改扇形（Patch）的颜色，跳过文本（Text）对象
patch_idx = 1:2:length(h_pie);  % 扇形对象固定在奇数索引
for i = 1:length(patch_idx)
    h_pie(patch_idx(i)).FaceColor = customColormap(i, :);  % customColormap 与主图颜色一致
end

% ------------- （4）隐藏饼图坐标轴（可选，更简洁） -------------
axis(ax_pie, 'off');
%% 2014-2023
%% trend
clc; clear;

% 读取数据
[trend, R] = readgeoraster('D:\\LYGNDVI\\trend2014.tif');

% 将 sig 中为 0 的值设置为 NaN
trend(trend == 0) = nan;

% 自定义颜色映射矩阵
customColormap = [
    0, 0.5, 0;   % 极显著增加（绿色）
    0.5, 1, 0;   % 显著增加（浅绿色）
    1, 1, 0;     % 稳定（黄色）
    1, 0.5, 0;   % 显著减少（浅橙色）
];

% 获取数据的大小
[rows, cols] = size(trend);

% 创建经纬度网格
lat = linspace(R.LatitudeLimits(1), R.LatitudeLimits(2), rows);
lon = linspace(R.LongitudeLimits(1), R.LongitudeLimits(2), cols);
[lon, lat] = meshgrid(lon, lat);  % 经度在列，纬度在行

% 绘制 pcolor 图
figure;
pcolor(lon, lat, flipud(trend));
shading flat;  % 使用平坦着色，使色块显示为整块

% 自定义颜色图
colormap(customColormap);  % 不显示白色

% 绘制图例
hold on;
cmap1 = customColormap;  % 使用自定义颜色
  legendLabels = {'','增加—持续', '增加—反持续', '减少—持续', '减少—反持续'};
for i = 1:4
    plot(inf, inf, 'color', cmap1(i, :), 'linewidth', 10);  % 隐藏的占位符
end
 legend(legendLabels, 'Location', 'northeastoutside', 'FontSize', 12, 'FontName', '宋体');  % 设置字体为黑体

% 读取连云港市的 shp 文件
shapefile = 'D:\\连云港大气污染\\shp\\output\\连云港市.shp';
Lianyungang = readgeotable(shapefile);

% 绘制连云港市的边界叠加在栅格数据上
geoshow(Lianyungang, 'DisplayType', 'polygon', 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1);

% 设置字体为新罗马（Times New Roman）
set(gca, 'FontName', 'Times New Roman', 'FontSize', 12);

% 设置坐标轴标签为具体的经纬度（例如，50°N 和 50°E），并加上单位
xtickformat('degrees')  % 显示经度
ytickformat('degrees')  % 显示纬度

% 修改坐标轴标签
xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');
xticklabels(cellfun(@(x) sprintf('%.2f°E', x), num2cell(xticks), 'UniformOutput', false));  % 经度加上 °E
yticklabels(cellfun(@(x) sprintf('%.2f°N', x), num2cell(yticks), 'UniformOutput', false));  % 纬度加上 °N

% 设置坐标轴范围，增加边距
xlim([min(lon(:)) - 0.05, max(lon(:)) + 0.05]);  % 增大经度范围
ylim([min(lat(:)) - 0.05, max(lat(:)) + 0.05]);  % 增大纬度范围

% 设置边框加粗
set(gca, 'LineWidth', 2);  % 增加坐标轴边框的线宽

% 设置背景颜色
set(gcf, 'Color', 'w');


% 在左下角添加饼状图（占比分析）
% 计算各类型的占比
validData = trend(~isnan(trend));
total = length(validData);
count1 = sum(validData == 1);  % 极显著增加
count2 = sum(validData == 2);  % 显著增加
count3 = sum(validData == 3);  % 稳定
count4 = sum(validData == 4);  % 显著减少
percentages = [count1, count2, count3, count4] / total * 100;

% 创建饼图的子坐标轴
ax_pie = axes('Parent', gcf, 'Position', [0.15, 0.15, 0.2, 0.2]);

h_pie = pie(ax_pie, percentages);  % ax_pie 是饼图的坐标区对象

% ------------- （2）设置饼图颜色与主图一致 -------------
% 只修改扇形（Patch）的颜色，跳过文本（Text）对象
patch_idx = 1:2:length(h_pie);  % 扇形对象固定在奇数索引
for i = 1:length(patch_idx)
    h_pie(patch_idx(i)).FaceColor = customColormap(i, :);  % customColormap 与主图颜色一致
end

% ------------- （4）隐藏饼图坐标轴（可选，更简洁） -------------
axis(ax_pie, 'off');