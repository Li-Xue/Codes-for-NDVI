%% 2000-2003
clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 4; % 时间序列长度  %% 要改

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2000:2003      %% 要改
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 1999) = data; % 直接存储到三维数组     %% 要改
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

hurst_values = NaN(m, n); % 初始化 Hurst 指数的存储
series_num = num-1; % 差值序列长度
for i = 1:m
    for j = 1:n
        series = squeeze(datasum(i, j, :)); % 获取时间序列数据，其长度等于num
        series_diff = diff(series); % 计算差值序列
        series_mean = cumsum(series_diff) ./ (1:length(series_diff))'; % 计算差值序列均值
 
        series_X = zeros(1, series_num); % 累积离差
        series_S = zeros(1, series_num); % 极差
        series_R = zeros(1, series_num); % 标准差
        for ii = 1:series_num
            der = series_diff(1:ii) - series_mean(ii);
            series_X(1:ii) = cumsum(der);
            series_R(ii) = max(series_X(1:ii)) - min(series_X(1:ii));
            if ii > 1
                series_S(ii) = sqrt(mean(der.^2));
            else
                series_S(ii) = 0;
            end
        end
        RS = series_R(2:series_num)./series_S(2:series_num);
        lag = 2:series_num;
        g = polyfit(log(lag/2),log(RS),1); % 取对数拟合
        hurst_values(i,j) = g(1);
    end
end

% 写入GeoTIFF
geotiffwrite('D:\\LYGNDVI\\hurst2000.tif', hurst_values, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2004-2013
clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 10; % 时间序列长度  %% 要改

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2004:2013      %% 要改
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 2003) = data; % 直接存储到三维数组     %% 要改
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

hurst_values = NaN(m, n); % 初始化 Hurst 指数的存储
series_num = num-1; % 差值序列长度
for i = 1:m
    for j = 1:n
        series = squeeze(datasum(i, j, :)); % 获取时间序列数据，其长度等于num
        series_diff = diff(series); % 计算差值序列
        series_mean = cumsum(series_diff) ./ (1:length(series_diff))'; % 计算差值序列均值
 
        series_X = zeros(1, series_num); % 累积离差
        series_S = zeros(1, series_num); % 极差
        series_R = zeros(1, series_num); % 标准差
        for ii = 1:series_num
            der = series_diff(1:ii) - series_mean(ii);
            series_X(1:ii) = cumsum(der);
            series_R(ii) = max(series_X(1:ii)) - min(series_X(1:ii));
            if ii > 1
                series_S(ii) = sqrt(mean(der.^2));
            else
                series_S(ii) = 0;
            end
        end
        RS = series_R(2:series_num)./series_S(2:series_num);
        lag = 2:series_num;
        g = polyfit(log(lag/2),log(RS),1); % 取对数拟合
        hurst_values(i,j) = g(1);
    end
end

% 写入GeoTIFF
geotiffwrite('D:\\LYGNDVI\\hurst2004.tif', hurst_values, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2014-2023
clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 10; % 时间序列长度  %% 要改

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2014:2023      %% 要改
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 2013) = data; % 直接存储到三维数组     %% 要改
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum=datasum*0.0001;

hurst_values = NaN(m, n); % 初始化 Hurst 指数的存储
series_num = num-1; % 差值序列长度
for i = 1:m
    for j = 1:n
        series = squeeze(datasum(i, j, :)); % 获取时间序列数据，其长度等于num
        series_diff = diff(series); % 计算差值序列
        series_mean = cumsum(series_diff) ./ (1:length(series_diff))'; % 计算差值序列均值
 
        series_X = zeros(1, series_num); % 累积离差
        series_S = zeros(1, series_num); % 极差
        series_R = zeros(1, series_num); % 标准差
        for ii = 1:series_num
            der = series_diff(1:ii) - series_mean(ii);
            series_X(1:ii) = cumsum(der);
            series_R(ii) = max(series_X(1:ii)) - min(series_X(1:ii));
            if ii > 1
                series_S(ii) = sqrt(mean(der.^2));
            else
                series_S(ii) = 0;
            end
        end
        RS = series_R(2:series_num)./series_S(2:series_num);
        lag = 2:series_num;
        g = polyfit(log(lag/2),log(RS),1); % 取对数拟合
        hurst_values(i,j) = g(1);
    end
end

% 写入GeoTIFF
geotiffwrite('D:\\LYGNDVI\\hurst2014.tif', hurst_values, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);












%%
























































%%
clear; clc;

% 读取任意影像加载投影等信息
[a, R] = geotiffread('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
info = geotiffinfo('D:\\LYGNDVI\\NDVIMeans\\2000ave.tif');
[m, n] = size(a);
num = 24; % 时间序列长度

datasum = NaN(m, n, num); % 使用三维数组来存储数据
% 循环读取每一年的数据
for year = 2000:2023
    filename = sprintf('D:\\LYGNDVI\\NDVIMeans\\%dave.tif', year);
    data = geotiffread(filename); % 使用geotiffread
    datasum(:, :, year - 1999) = data; % 直接存储到三维数组
end

% 需要对数据进行处理
% scale: 0.0001
% background value: -9999
% non-vegetated areas: 670
datasum(datasum < 0) = NaN; 
datasum(datasum == -9999) = NaN; 
datasum(datasum == 670) = NaN; 
datasum = datasum * 0.0001;

% 初始化结果数组
hurst_values = NaN(m, n);       % Hurst指数
adf_pvalues = NaN(m, n);        % ADF检验p值
adf_statistic = NaN(m, n);      % ADF检验统计量
adf_result = false(m, n);       % ADF平稳性结果
kpss_pvalues = NaN(m, n);       % KPSS检验p值
kpss_statistic = NaN(m, n);     % KPSS检验统计量
kpss_result = false(m, n);      % KPSS平稳性结果
consensus = zeros(m, n);        % 两种检验的一致性（0=不一致，1=一致平稳，2=一致非平稳）

series_num = num-1; % 差值序列长度
min_samples = 8;    % 最小有效样本数（调整为8以适应KPSS）

for i = 1:m
    for j = 1:n
        % 获取时间序列数据
        series = squeeze(datasum(i, j, :)); % 其长度等于num
        
        % 跳过全为NaN的像元
        if all(isnan(series))
            continue;
        end
        
        % 1. 计算Hurst指数（保持原有逻辑不变）
        series_diff = diff(series); % 计算差值序列
        series_mean = cumsum(series_diff) ./ (1:length(series_diff))'; % 计算差值序列均值
 
        series_X = zeros(1, series_num); % 累积离差
        series_S = zeros(1, series_num); % 极差
        series_R = zeros(1, series_num); % 标准差
        for ii = 1:series_num
            der = series_diff(1:ii) - series_mean(ii);
            series_X(1:ii) = cumsum(der);
            series_R(ii) = max(series_X(1:ii)) - min(series_X(1:ii));
            if ii > 1
                series_S(ii) = sqrt(mean(der.^2));
            else
                series_S(ii) = 0;
            end
        end
        RS = series_R(2:series_num)./series_S(2:series_num);
        lag = 2:series_num;
        g = polyfit(log(lag/2), log(RS), 1); % 取对数拟合
        hurst_values(i,j) = g(1);
        
        % 2. 处理缺失值
        if any(isnan(series))
            x = 1:length(series);
            series = fillmissing(series, 'linear');
        end
        
        % 3. 确保有效样本量足够
        if length(series) < min_samples
            continue; % 样本量不足，跳过此像元
        end
        
        % 4. 进行ADF检验（使用自定义函数）
        [adf_stat, adf_p, adf_h] = custom_adftest(series, 'ts');
        adf_pvalues(i,j) = adf_p;
        adf_statistic(i,j) = adf_stat;
        adf_result(i,j) = adf_h; % true表示平稳
        
        % 5. 进行KPSS检验（新增）
        [kpss_stat, kpss_p, kpss_h] = custom_kpsstest(series, 'c');
        kpss_pvalues(i,j) = kpss_p;
        kpss_statistic(i,j) = kpss_stat;
        kpss_result(i,j) = ~kpss_h; % KPSS中h=true表示拒绝平稳，需取反
        
        % 6. 综合两种检验结果（新增）
        if adf_result(i,j) && kpss_result(i,j)
            consensus(i,j) = 1; % 一致认为平稳
        elseif ~adf_result(i,j) && ~kpss_result(i,j)
            consensus(i,j) = 2; % 一致认为非平稳
        else
            consensus(i,j) = 0; % 不一致
        end
    end
end

% 保存结果
geotiffwrite('hurst_index.tif', hurst_values, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('adf_pvalues.tif', adf_pvalues, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('adf_statistic.tif', adf_statistic, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('adf_result.tif', uint8(adf_result), R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('kpss_pvalues.tif', kpss_pvalues, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('kpss_statistic.tif', kpss_statistic, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('kpss_result.tif', uint8(kpss_result), R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('consensus.tif', uint8(consensus), R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

% 可视化结果示例
figure('Position', [100, 100, 1200, 800]);
subplot(2,3,1); imagesc(hurst_values); title('Hurst指数'); colorbar;
subplot(2,3,2); imagesc(adf_pvalues); title('ADF检验p值'); colorbar;
subplot(2,3,3); imagesc(kpss_pvalues); title('KPSS检验p值'); colorbar;
subplot(2,3,4); imagesc(adf_result); title('ADF平稳性结果'); colorbar;
subplot(2,3,5); imagesc(kpss_result); title('KPSS平稳性结果'); colorbar;
subplot(2,3,6); imagesc(consensus); title('检验一致性(0=不一致,1=平稳,2=非平稳)'); colorbar;


