%% 2000-2023
clear; clc;

% 读取坡度影像和投影信息
[slope, R] = geotiffread('D:\\LYGNDVI\\slope.tif');
info = geotiffinfo('D:\\LYGNDVI\\slope.tif');
[m, n] = size(slope);

% 读取Hurst指数影像
hurst = geotiffread('D:\\LYGNDVI\\hurst.tif');
  
% 条件判断并生成结果影像（向量化操作）
result = NaN(m, n);
idx1 = slope > 0 & hurst > 0.5;
idx2 = slope > 0 & hurst < 0.5;
idx3 = slope < 0 & hurst > 0.5;
idx4 = slope < 0 & hurst < 0.5;
result(idx1) = 1; % 增加，持续
result(idx2) = 2; % 增加，反持续
result(idx3) = 3; % 减少，持续
result(idx4) = 4; % 减少，反持续

% 写入结果影像
geotiffwrite('D:\\LYGNDVI\\trend.tif', result, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2000-2003
clear; clc;

% 读取坡度影像和投影信息
[sen, R] = geotiffread('D:\\LYGNDVI\\sen2000.tif');
info = geotiffinfo('D:\\LYGNDVI\\sen2000.tif');
[m, n] = size(sen);

% 读取Hurst指数影像
hurst = geotiffread('D:\\LYGNDVI\\hurst2000.tif');
  
% 条件判断并生成结果影像（向量化操作）
result = NaN(m, n);
idx1 = sen > 0 & hurst > 0.5;
idx2 = sen > 0 & hurst < 0.5;
idx3 = sen < 0 & hurst > 0.5;
idx4 = sen < 0 & hurst < 0.5;
result(idx1) = 1; % 增加，持续
result(idx2) = 2; % 增加，反持续
result(idx3) = 3; % 减少，持续
result(idx4) = 4; % 减少，反持续

% 写入结果影像
geotiffwrite('D:\\LYGNDVI\\trend2000.tif', result, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% 2004-2013
clear; clc;

% 读取坡度影像和投影信息
[sen, R] = geotiffread('D:\\LYGNDVI\\sen2004.tif');
info = geotiffinfo('D:\\LYGNDVI\\sen2004.tif');
[m, n] = size(sen);

% 读取Hurst指数影像
hurst = geotiffread('D:\\LYGNDVI\\hurst2004.tif');
  
% 条件判断并生成结果影像（向量化操作）
result = NaN(m, n);
idx1 = sen > 0 & hurst > 0.5;
idx2 = sen > 0 & hurst < 0.5;
idx3 = sen < 0 & hurst > 0.5;
idx4 = sen < 0 & hurst < 0.5;
result(idx1) = 1; % 增加，持续
result(idx2) = 2; % 增加，反持续
result(idx3) = 3; % 减少，持续
result(idx4) = 4; % 减少，反持续

% 写入结果影像
geotiffwrite('D:\\LYGNDVI\\trend2004.tif', result, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);


%% 2004-2013
clear; clc;

% 读取坡度影像和投影信息
[sen, R] = geotiffread('D:\\LYGNDVI\\sen2014.tif');
info = geotiffinfo('D:\\LYGNDVI\\sen2014.tif');
[m, n] = size(sen);

% 读取Hurst指数影像
hurst = geotiffread('D:\\LYGNDVI\\hurst2014.tif');
  
% 条件判断并生成结果影像（向量化操作）
result = NaN(m, n);
idx1 = sen > 0 & hurst > 0.5;
idx2 = sen > 0 & hurst < 0.5;
idx3 = sen < 0 & hurst > 0.5;
idx4 = sen < 0 & hurst < 0.5;
result(idx1) = 1; % 增加，持续
result(idx2) = 2; % 增加，反持续
result(idx3) = 3; % 减少，持续
result(idx4) = 4; % 减少，反持续

% 写入结果影像
geotiffwrite('D:\\LYGNDVI\\trend2014.tif', result, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);